<?php
include_once('../views/elements/tryFirst.php');
if(strtoupper($_SERVER['REQUEST_METHOD']) == 'POST'){
    $childFirstNameX = new tryFirst($_POST['childfirstName'],"Child's First Name");
    $errors = $childFirstNameX->validate_name();
    if(count($errors)>0){
        $childFirstNameX->error_print($errors);
    }else{
        echo "Your input for Child's First name \"".$_POST['childfirstName']."\"";
    }

}