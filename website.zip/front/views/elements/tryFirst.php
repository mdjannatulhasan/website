<?php


class tryFirst
{
    public $part;
    public $vName;

    function __construct($input, $inputV){
        $this->part = $input;
        $this->vName = $inputV;
    }
    function validate_name(){
        $name = $this->part;
        $errors=[];
        if(empty($name)){
            $errors[]= "$this->vName can not be empty";
        }
        if(!ctype_alpha($name)){
            $errors[] ="$this->vName should be Alphabet only";
        }
        return $errors;
    }
    function error_print($ar){
        echo "<ul>";
        foreach ($ar as $error) {
            echo "<li>";
            echo "$error";
            echo "</li>";
        }
        echo "</ul>";

    }
}