<?php
?>
<section class="head">
    <div class="container">
        <div class="title h1 text-center">
            U. S. Standard Certificate of Live Birth
        </div>
    </div>
</section>
